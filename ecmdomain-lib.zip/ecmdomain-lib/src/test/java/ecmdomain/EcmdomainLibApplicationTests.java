package ecmdomain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcmdomainLibApplicationTests {

	@Test
	void contextLoads() {
	}

}
