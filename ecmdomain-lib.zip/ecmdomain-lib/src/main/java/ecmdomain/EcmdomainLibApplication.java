package ecmdomain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcmdomainLibApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcmdomainLibApplication.class, args);
	}

}
